Pertama Download Dulu App Termux di Play Store
Jika Sudah Punya Langsung Saja

#------------------------------------------------------------------------#

Untuk Pengguna Yang Baru Install Termux Lakukan Seperti Berikut

pkg install python2 -y

pkg install git -y

git clone https://github.com/lianekof/Chivas-TCR

pip2 install rsa

pip2 install requests

pip2 install thrift==0.9.3

cd Chivas-TCR

python2 tcr-v1.py

#------------------------------------------------------------------------#

Jika Sudah Pernah Isntall Python2 + Git + Pip2 Tinggal Lakukan 

git clone https://github.com/lianekof/Chivas-TCR

cd Chivas-TCR

python2 tcr-v1.py

#------------------------------------------------------------------------#

Id line : lianekof

Support by RA-Family
